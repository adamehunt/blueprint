=== WS Form PRO - Google Sheets ===
Contributors: westguard
Requires at least: 4.4
Tested up to: 6.2
Stable tag: trunk
Requires PHP: 5.2.2

Google Sheets add-on for WS Form PRO.

== Description ==

Google Sheets add-on for WS Form PRO.

== Installation ==

For help installing this plugin, please see our [Installation](https://wsform.com/knowledgebase/installation/?utm_source=wp_plugins&utm_medium=readme) knowledgebase article.

== Changelog ==

= 1.0.29 - 04/24/23 =
* Bug Fix: Revoking token failure

= 1.0.28 - 04/23/23 =
* Added: Improvements to oAuth process

= 1.0.27 - 02/24/23 =
* Added: Error checking when creating Google client instance

= 1.0.26 - 12/15/22 =
* Added: Fix to number type formatting

= 1.0.25 - 10/06/22 =
* Added: Composer classmap-authoritative implemented to avoid conflicts

= 1.0.24 - 10/05/22 =
* Bug Fix: Google Sheets data source requesting data from sheet other than first

= 1.0.23 - 06/24/22 =
* Added: Google Sheets data source
* Added: Improved refresh token API request failure handling
* Changed: Google SDK updated

= 1.0.22 - 04/26/22 =
* Bug Fix: Field ID in cache array for custom field mapping

= 1.0.21 - 12/28/21 =
* Added: Setting for mapping file and signature fields as URLs instead of file names

= 1.0.20 - 11/08/21 =
* Bug Fix: Time cell formatting

= 1.0.19 - 09/10/21 =
* Bug Fix: Repeatable section field values now fallback to text cell type

= 1.0.18 - 07/08/21 =
* Changed: Google SDK updated

= 1.0.17 - 03/23/21 =
* Bug Fix: Removed account_refresh_info method

= 1.0.16 - 03/11/21 =
* Bug Fix: Removed from Form --> Data tab

= 1.0.15 - 02/07/21 =
* Bug Fix: Check to see if sub list selected

= 1.0.14 - 02/07/21 =
* Changed: File list now excludes trashed files

= 1.0.13 - 12/16/20 =
* Bug Fix: Submitting blank values

= 1.0.12 - 09/02/20 =
* Added: Unique field mapping
* Changed: REST API authentication

= 1.0.11 - 08/01/20 =
* Added: Access token revoking on disconnect

= 1.0.10 - 06/15/20 =
* Added: Ability to stack Google sheet calls to different sheets

= 1.0.9 - 06/07/20 =
* Bug Fix: Blank column handling

= 1.0.8 - 06/03/20 =
* Added: Support for irregular column mapping

= 1.0.7 - 05/28/20 =
* Added: Month cell formatting
* Changed: Improved text coloring on color field
* Changed: Improved date/time formatting for international dated

= 1.0.6 - 05/13/20 =
* Added: Updates for new data structure

= 1.0.5 - 05/13/20 =
* Added: Checks for blank column values

= 1.0.4 - 04/24/20 =
* Changed: Action priority

= 1.0.3 - 04/11/20 =
* Bug Fix: Submit value parsing

= 1.0.2 - 03/29/20 =
* Bug Fix: Refresh token fix

= 1.0.1 - 03/22/20 =
* Bug Fix: Custom field mapping

= 1.0.0 - 01/13/20 =
* Initial release.
