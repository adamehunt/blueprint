<?php
	/**
	 * Silence is golden
	 *
	 * @link              https://wsform.com/
	 * @since             1.0.0
	 * @package           WS_Form_PRO
	 */

	// Nothing to see here.
