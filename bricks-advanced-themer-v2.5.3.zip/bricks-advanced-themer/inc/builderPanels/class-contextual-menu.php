<?php
namespace Advanced_Themer_Bricks;
if (!defined('ABSPATH')) { die();
}

?>
<div id="brxc-class-context-menu">
    <div id="brxc-class-context-menu-canvas"></div>
</div>