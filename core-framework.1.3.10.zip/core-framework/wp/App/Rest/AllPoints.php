<?php

/**
 * CoreFramework
 *
 * @package   CoreFramework
 * @author    Core Framework <hello@coreframework.com>
 * @copyright 2023 Core Framework
 * @license   EULA + GPLv2
 * @link      https://coreframework.com
 */

declare(strict_types=1);

namespace CoreFramework\App\Rest;

use CoreFramework\Common\Abstracts\Base;
use CoreFramework\Helper;

/**
 * Class AllPoints
 *
 * @package CoreFramework\App\Rest
 * @since 0.0.0
 */
class AllPoints extends Base {

	/**
	 * Initialize the class.
	 *
	 * @since 0.0.0
	 */
	public function init() {
		/**
		 * This class is only being instantiated if REST_REQUEST is defined in the requester as requested in the Scaffold class
		 *
		 * @see Requester::isRest()
		 * @see Scaffold::__construct
		 */

		if ( class_exists( 'WP_REST_Server' ) ) {
			\add_action( 'rest_api_init', array( $this, 'add_plugin_rest_api' ) );
		}
	}

	/**
	 * @since 0.0.0
	 */
	public function add_plugin_rest_api() {
		$this->register_routes();
		$this->register_options();
	}

	/**
	 * @since   0.0.0
	 * @version 1.0
	 */
	public function register_options(): void {
		$preferences = array(
			'oxygen'                               => array(
				'type' => 'boolean',
			),
			'bricks'                               => array(
				'type' => 'boolean',
			),
			'gutenberg'                            => array(
				'type' => 'boolean',
			),
			'selected_id'                          => array(
				'type' => 'string',
			),
			'delete_data'                          => array(
				'type' => 'boolean',
			),
			'show_update_notice'                   => array(
				'type' => 'boolean',
			),
			'theme_mode'                           => array(
				'type' => 'string',
			),
			'has_theme'                            => array(
				'type' => 'boolean',
			),
			'oxygen_enable_variable_dropdown'      => array(
				'type' => 'boolean',
			),
			'oxygen_enable_dark_mode_preview'      => array(
				'type' => 'boolean',
			),
			'oxygen_variable_ui'                   => array(
				'type' => 'boolean',
			),
			'oxygen_enable_variable_ui_auto_hide'  => array(
				'type' => 'boolean',
			),
			'oxygen_enable_variable_ui_hint'       => array(
				'type' => 'boolean',
			),
			'oxygen_apply_class_on_hover'          => array(
				'type' => 'boolean',
			),
			'oxygen_enable_variable_context_menu'  => array(
				'type' => 'boolean',
			),
			'oxygen_enable_unit_and_value_preview' => array(
				'type' => 'boolean',
			),
			'bricks_enable_variable_dropdown'      => array(
				'type' => 'boolean',
			),
			'bricks_enable_dark_mode_preview'      => array(
				'type' => 'boolean',
			),
			'bricks_variable_ui'                   => array(
				'type' => 'boolean',
			),
			'bricks_enable_variable_ui_auto_hide'  => array(
				'type' => 'boolean',
			),
			'bricks_enable_variable_ui_hint'       => array(
				'type' => 'boolean',
			),
			'bricks_apply_class_on_hover'          => array(
				'type' => 'boolean',
			),
			'bricks_enable_variable_context_menu'  => array(
				'type' => 'boolean',
			),
			'gutenberg_enable_dark_mode_preview'   => array(
				'type' => 'boolean',
			),
			'gutenberg_place_controls_at_the_top'  => array(
				'type' => 'boolean',
			),
			// Legacy
			'root_font_size'                       => array(
				'type' => 'number',
			),
			'postcss'                              => array(
				'type' => 'boolean',
			),
			'min_screen_width'                     => array(
				'type' => 'number',
			),
			'max_screen_width'                     => array(
				'type' => 'number',
			),
			'is_rem'                               => array(
				'type' => 'boolean',
			),
		);

		\register_setting(
			'core_framework',
			'core_framework_main',
			array(
				'type'         => 'object',
				'show_in_rest' => array(
					'schema' => array(
						'type'       => 'object',
						'properties' => $preferences,
					),
				),
			)
		);
	}

	protected function permission( string $nonce, bool $readonly_capabilites = false ): bool {
		if ( ! isset( $nonce ) || empty( $nonce ) ) {
			return false;
		}

		if ( $readonly_capabilites ) {
			return ( \current_user_can( 'manage_options' ) || \current_user_can( 'editor' ) ) && \wp_verify_nonce( $nonce, 'wp_rest' );
		}

		return \current_user_can( 'manage_options' ) && \wp_verify_nonce( $nonce, 'wp_rest' );
	}

	/**
	 * @since 0.0.0
	 * @return bool
	 */
	public function verify_nonce( \WP_REST_Request $request ): bool {
		$route           = $request->get_route() ?? '';
		$readonly_routes = array(
			'/get-builders',
			'/get-classes',
			'/get-variables',
			'/builders-var-ui',
		);

		foreach ( $readonly_routes as $key => $value ) {
			$readonly_routes[ $key ] = '/core-framework/v2' . $value;
		}

		$nonce = $request->get_header( 'X-WP-Nonce' );
		return $this->permission( $nonce, in_array( $route, $readonly_routes ) );
	}

	/**
	 * Register the routes
	 *
	 * @return void
	 * @since 0.0.0
	 */
	public function register_routes() {
		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/update-presets',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'update_presets' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);

		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/delete-preset',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'delete_preset_row' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);

		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/get-preset-row',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_preset_row' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);

		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/update-main',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'update_main' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);

		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/update-colors',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'update_colors' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);

		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/update-classes',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'update_classes' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);

		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/update-grouped-classes',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'update_grouped_classes' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);

		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/get-builders',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_builders' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);

		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/get-license-keys',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_license_keys' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);

		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/update-license-key',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'update_license_key' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);

		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/get-classes',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_classes' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);

		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/update-prefixed-css-file',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'update_prefixed_css_file' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);

		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/save-oxygen-css-helper',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'save_oxygen_css_helper' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);

		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/get-variables',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_variables' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);

		register_rest_route(
			CORE_FRAMEWORK_NAME . '/v2',
			'/builders-var-ui',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'builders_var_ui' ),
				'permission_callback' => array( $this, 'verify_nonce' ),
			)
		);
	}

	/**
	 * Update the 'core_framework_presets' table
	 *
	 * @since 0.0.0
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response
	 */
	public function update_presets( \WP_REST_Request $request ) {
		$data = $request->get_param( 'data' ) ?? '';
		$id   = $request->get_param( 'id' ) ?? '';

		$time = \current_time( 'mysql' );

		global $wpdb;
		$table_name   = $wpdb->prefix . 'core_framework_presets';
		$target_table = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) );

		if ( $target_table != $table_name ) {
			CoreFramework()->createTable();
		}

		$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table_name WHERE id = %s", $id ) );

		if ( $exists ) {
			$wpdb->update(
				$table_name,
				array(
					'id'   => $id,
					'time' => $time,
					'data' => $data,
				),
				array( 'id' => $id )
			);

			if ( \is_wp_error( $wpdb->insert_id ) ) {
				http_response_code( 400 );
				exit();
			}

			CoreFramework()->purge_cache();

			return new \WP_REST_Response(
				array(
					'success' => true,
					'action'  => 'updated',
				)
			);
		}

		$wpdb->insert(
			$table_name,
			array(
				'id'   => $id,
				'time' => $time,
				'data' => $data,
			)
		);

		if ( \is_wp_error( $wpdb->insert_id ) ) {
			http_response_code( 400 );
			exit();
		}

		CoreFramework()->purge_cache();

		return new \WP_REST_Response(
			array(
				'success' => true,
				'action'  => 'created',
			)
		);
	}

	/**
	 * Delete a row from the 'core_framework_presets' table
	 *
	 * @since 0.0.0
	 * @param \WP_REST_Request $request { id: string }
	 * @return \WP_REST_Response
	 */
	public function delete_preset_row( \WP_REST_Request $request ) {
		$id = $request->get_param( 'id' ) ?? '';

		global $wpdb;
		$table_name = $wpdb->prefix . 'core_framework_presets';

		$wpdb->delete(
			$table_name,
			array( 'id' => $id )
		);

		if ( \is_wp_error( $wpdb->insert_id ) ) {
			http_response_code( 400 );
			exit();
		}

		CoreFramework()->purge_cache();

		return new \WP_REST_Response(
			array(
				'success' => true,
				'action'  => 'deleted',
			)
		);
	}

	/**
	 * Returns a row from the 'core_framework_presets' table
	 *
	 * @since 0.0.0
	 * @param \WP_REST_Request $request { id: string }
	 * @return \WP_REST_Response { success: boolean, data: Row }
	 */
	public function get_preset_row( \WP_REST_Request $request ) {
		$id = $request->get_param( 'id' ) ?? '';

		global $wpdb;
		$table_name = $wpdb->prefix . 'core_framework_presets';
		$row        = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM $table_name WHERE id = %s", $id )
		);

		if ( \is_wp_error( $row ) ) {
			http_response_code( 400 );
			exit();
		}

		return new \WP_REST_Response(
			array(
				'success' => $row ? true : false,
				'data'    => $row,
			)
		);
	}

	/**
	 * Updates code and id in `core_framework_main` table
	 *
	 * @since 0.0.0
	 * @param \WP_REST_Request $request
	 * @return \WP_REST_Response
	 */
	public function update_main( \WP_REST_Request $request ) {
		$cssString = $request->get_param( 'cssString' ) ?? '';
		$id        = $request->get_param( 'id' ) ?? '';

		if ( ! $cssString || ! $id ) {
			http_response_code( 400 );
			exit();
		}

		$option_name             = 'core_framework_main';
		$settings                = \get_option( $option_name );
		$settings['selected_id'] = $id;

		\update_option( $option_name, $settings, false );

		$plugins_root = WP_CONTENT_DIR . '/plugins';

		if ( is_multisite() ) {
			$bytes_saved = \file_put_contents( $plugins_root . '/core-framework/assets/public/css/core_framework_' . get_current_blog_id() . '.css', $cssString );
		} else {
			$bytes_saved = \file_put_contents( $plugins_root . '/core-framework/assets/public/css/core_framework.css', $cssString );
		}

		if ( \is_wp_error( $settings ) ) {
			http_response_code( 400 );
			exit();
		}

		\update_option( 'core_framework_selected_preset_backup', $cssString, false );

		CoreFramework()->purge_cache();

		return new \WP_REST_Response(
			array(
				'success'      => true,
				'bytes_saved'  => $bytes_saved,
				'is_multisite' => is_multisite(),
				'blog_id'      => get_current_blog_id(),
			)
		);
	}

	/**
	 * Class names sync
	 *
	 * @since 0.0.0
	 */
	public function update_classes( $request ) {
		$classes            = $request->get_param( 'classes' ) ?? '';
		$addon_enable_array = $request->get_param( 'addonEnableArray' ) ?? array();

		if ( $classes === null || $addon_enable_array === null ) {
			http_response_code( 400 );
			exit();
		}

		$new_selectors_array = explode( ',', $classes ) ?? array();
		$builder_array       = array(
			'oxygen' => array(
				'is_active'     => CoreFrameworkOxygen()->is_oxygen(),
				'class'         => CoreFrameworkOxygen(),
				'key'           => 'oxygen',
				'addon_license' => array_search( 'oxygen', array_column( $addon_enable_array, 'addon' ) ) !== false ? true : false,
			),
			'bricks' => array(
				'is_active'     => CoreFrameworkBricks()->is_bricks(),
				'class'         => CoreFrameworkBricks(),
				'key'           => 'bricks',
				'addon_license' => array_search( 'bricks', array_column( $addon_enable_array, 'addon' ) ) !== false ? true : false,
			),
		);

		$active_builders = array();
		$core_option     = \get_option( 'core_framework_main' );

		foreach ( $builder_array as $builder ) {
			if ( ! $builder['is_active'] ) {
				continue;
			}

			if ( ! $builder['addon_license'] ) {
				continue;
			}

			if ( ! $core_option[ $builder['key'] ] ) {
				continue;
			}

			$builder['class']->refresh_selectors( $new_selectors_array );
			$active_builders[] = $builder['key'];

			break;
		}

		return new \WP_REST_Response(
			array(
				'success'         => true,
				'active_builders' => $active_builders,
			)
		);
	}

	/**
	 * @since 1.0.3
	 */
	public function update_grouped_classes( $request ) {
		$grouped_classes = $request->get_param( 'groupedClassNames' ) ?? '';

		if ( $grouped_classes === null ) {
			http_response_code( 400 );
			exit();
		}

		$response = update_option( 'core_framework_grouped_classes', $grouped_classes, false );

		if ( \is_wp_error( $response ) ) {
			http_response_code( 400 );
			exit();
		}

		return new \WP_REST_Response(
			array(
				'success' => $response,
			)
		);
	}

	/**
	 * Color palette sync
	 *
	 * @since 0.0.0
	 * @param \WP_REST_Request
	 */
	public function update_colors( \WP_REST_Request $request ) {
		$colors             = $request->get_param( 'colors' ) ?? '';
		$addon_enable_array = $request->get_param( 'addonEnableArray' ) ?? array();

		if ( $colors === null ) {
			http_response_code( 400 );
			exit();
		}

		update_option( 'core_framework_colors', $colors, false );

		$builder_array   = array(
			'oxygen' => array(
				'is_active'     => CoreFrameworkOxygen()->is_oxygen(),
				'class'         => CoreFrameworkOxygen(),
				'key'           => 'oxygen',
				'addon_license' => array_search( 'oxygen', array_column( $addon_enable_array, 'addon' ) ) !== false ? true : false,
			),
			'bricks' => array(
				'is_active'     => CoreFrameworkBricks()->is_bricks(),
				'class'         => CoreFrameworkBricks(),
				'key'           => 'bricks',
				'addon_license' => array_search( 'bricks', array_column( $addon_enable_array, 'addon' ) ) !== false ? true : false,
			),
		);
		$active_builders = array();
		$core_setting    = \get_option( 'core_framework_main' );

		foreach ( $builder_array as $builder ) {
			if ( ! $builder['addon_license'] ) {
				continue;
			}

			if ( ! $builder['is_active'] ) {
				continue;
			}

			if ( ! $core_setting[ $builder['key'] ] ) {
				continue;
			}

			$builder['class']->update_colors( $colors );
			$active_builders[] = $builder['key'];

			break;
		}

		return new \WP_REST_Response(
			array(
				'success'         => true,
				'active_builders' => $active_builders,
			)
		);
	}

	/**
	 * Returns activate builders array
	 *
	 * @since 0.0.0
	 * @return \WP_REST_Response { builders: string[] }
	 */
	public function get_builders() {
		$builders       = array();
		$builders_array = array(
			'oxygen'    => CoreFrameworkOxygen()->is_oxygen(),
			'bricks'    => CoreFrameworkBricks()->is_bricks(),
			'gutenberg' => true,
		);

		foreach ( $builders_array as $key => $value ) {
			if ( $value ) {
				array_push( $builders, $key );
			}
		}

		return new \WP_REST_Response(
			array(
				'builders' => $builders,
			)
		);
	}

	/**
	 * Get license keys from the database
	 *
	 * @since 1.0.0
	 */
	public function get_license_keys() {
		$license_keys       = array();
		$license_keys_array = array(
			'oxygen' => '',
			'bricks' => '',
		);

		foreach ( $license_keys_array as $key => $value ) {
			$license_keys[ $key ] = get_option( 'core_framework_' . $key . '_license_key' );
		}

		return new \WP_REST_Response(
			array(
				'license_keys' => $license_keys,
			)
		);
	}

	/**
	 * Update license key in the database
	 *
	 * @since 1.0.0
	 */
	public function update_license_key( \WP_REST_Request $request ) {
		$license_key = $request->get_param( 'license_key' ) ?? '';
		$type        = $request->get_param( 'type' ) ?? '';

		if ( $license_key === null || $type === null ) {
			http_response_code( 400 );
			exit();
		}

		update_option( 'core_framework_' . $type . '_license_key', $license_key, false );

		CoreFramework()->purge_cache();

		return new \WP_REST_Response(
			array(
				'success' => true,
			)
		);
	}

	/**
	 * Get classes
	 *
	 * @since 1.0.0
	 */
	public function get_classes() {
		$classes = get_option( 'core_framework_grouped_classes' );

		return new \WP_REST_Response(
			array(
				'classes' => $classes,
			)
		);
	}

	/**
	 * @since 1.0.3
	 * @param \WP_REST_Request $request
	 */
	public function update_prefixed_css_file( \WP_REST_Request $request ) {
		$cssString = $request->get_param( 'cssString' ) ?? '';

		if ( ! $cssString ) {
			http_response_code( 400 );
			exit();
		}

		$success = update_option( 'core_framework_editor_prefixed_css', $cssString, false );

		if ( \is_wp_error( $success ) ) {
			http_response_code( 400 );
			exit();
		}

		CoreFramework()->purge_cache();

		return new \WP_REST_Response(
			array(
				'success' => $success,
			)
		);
	}

	/**
	 * @since 1.0.3
	 * @param \WP_REST_Request $request
	 */
	public function save_oxygen_css_helper( \WP_REST_Request $request ) {
		$cssString = $request->get_param( 'cssString' ) ?? '';

		if ( ! $cssString ) {
			http_response_code( 400 );
			exit();
		}

		$success = update_option( 'core_framework_oxygen_css_helper', $cssString, false );

		if ( \is_wp_error( $success ) ) {
			http_response_code( 400 );
			exit();
		}

		return new \WP_REST_Response(
			array(
				'success' => $success,
			)
		);
	}

	/**
	 * @since 1.2.4
	 */
	public function get_variables( \WP_REST_Request $request ) {
		$type = $request->get_param( 'type' ) ?? '';

		if ( $type === 'oxygen_dropdown' || $type === 'bricks_dropdown' ) {
			$helper    = new Helper();
			$variables = $helper->getVariables(
				array(
					'group_by_category' => true,
				)
			);

			return new \WP_REST_Response(
				array(
					'variables' => $variables,
				)
			);
		}

		$helper    = new Helper();
		$variables = $helper->getVariables(
			array(
				'group_by_category' => false,
				'excluded_keys'     => array( 'colorStyles' ),
			)
		);

		return new \WP_REST_Response(
			array(
				'variables' => $variables,
			)
		);
	}

	/**
	 *
	 * @since 1.3.0
	 * @return mixed
	 */
	public function builders_var_ui() {
		$empty_response = array(
			'variables'                          => array(),
			'color_system_data'                  => array(),
			'variable_prefix'                    => '',
			'fluid_typography_naming_convention' => '',
			'fluid_spacing_naming_convention'    => '',
		);
		$options        = get_option( 'core_framework_main' );
		$is_bricks      = isset( $options['bricks'] ) ? $options['bricks'] : false;
		$is_oxygen      = isset( $options['oxygen'] ) ? $options['oxygen'] : false;

		if ( ! $is_bricks && ! $is_oxygen ) {
			return new \WP_REST_Response(
				$empty_response
			);
		}

		$key = $is_bricks ? get_option( 'core_framework_bricks_license_key' ) : get_option( 'core_framework_oxygen_license_key' );

		if ( ! $key ) {
			return new \WP_REST_Response(
				$empty_response
			);
		}

		$response = wp_remote_get( CORE_FRAMEWORK_EDD_STORE_URL . '?edd_action=check_license&item_id=' . ( $is_bricks ? '12' : '15' ) . '&license=' . $key . '&url=' . get_site_url() . '&version=' . CORE_FRAMEWORK_VERSION );
		$res_json = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( isset( $res_json['license'] ) && $res_json['success'] === false ) {
			return new \WP_REST_Response(
				$empty_response
			);
		}

		$helper    = new Helper();
		$variables = $helper->getVariablesGroupedByCategoriesAndGroups(
			array(
				'group_by_category'              => true,
				'exclude_color_system_variables' => true,
			)
		);

		$preset = $helper->getPreset();

		$color_system_data                  = isset( $preset['modulesData'] ) && isset( $preset['modulesData']['COLOR_SYSTEM'] ) ? $preset['modulesData']['COLOR_SYSTEM'] : array();
		$variable_prefix                    = isset( $preset['variablePrefix'] ) ? $preset['variablePrefix'] : '';
		$fluid_typography_naming_convention = isset( $preset['modulesData']['FLUID_TYPOGRAPHY'] ) && isset( $preset['modulesData']['FLUID_TYPOGRAPHY']['namingConvention'] ) ? $preset['modulesData']['FLUID_TYPOGRAPHY']['namingConvention'] : '';
		$fluid_spacing_naming_convention    = isset( $preset['modulesData']['FLUID_SPACING'] ) && isset( $preset['modulesData']['FLUID_SPACING']['namingConvention'] ) ? $preset['modulesData']['FLUID_SPACING']['namingConvention'] : '';

		return new \WP_REST_Response(
			array(
				'variables'                          => $variables,
				'color_system_data'                  => $color_system_data,
				'variable_prefix'                    => $variable_prefix,
				'fluid_typography_naming_convention' => $fluid_typography_naming_convention,
				'fluid_spacing_naming_convention'    => $fluid_spacing_naming_convention,
			)
		);
	}
}
