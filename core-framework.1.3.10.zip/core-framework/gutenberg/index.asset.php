<?php return array('dependencies' => array('react', 'wp-block-editor', 'wp-components', 'wp-compose', 'wp-data', 'wp-element', 'wp-plugins'), 'version' => '19c3910d3323e3ea2f38');
