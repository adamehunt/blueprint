<?php

	/**
	 * @link              https://wsform.com/knowledgebase/google-sheets/
	 * @since             1.0.0
	 * @package           WS_Form_Google_Sheets
	 *
	 * @wordpress-plugin
	 * Plugin Name:       WS Form PRO - Google Sheets
	 * Plugin URI:        https://wsform.com/knowledgebase/google-sheets/
	 * Description:       Google Sheets add-on for WS Form PRO
	 * Version:           1.0.29
 	 * Author:            WS Form
  	 * Author URI:        https://wsform.com/
	 * Text Domain:       ws-form-google-sheets-v4
	 */

	Class WS_Form_Add_On_Google_Sheets_V4 {

		const WS_FORM_PRO_ID 			= 'ws-form-pro/ws-form.php';
		const WS_FORM_PRO_VERSION_MIN 	= '1.7.148';

		function __construct() {

			// Load plugin.php
			if(!function_exists('is_plugin_active')) {

				include_once(ABSPATH . 'wp-admin/includes/plugin.php');
			}

			// Admin init
			add_action('plugins_loaded', array($this, 'plugins_loaded'), 20);
		}

		function plugins_loaded() {

			if(self::is_dependency_ok()) {

				new WS_Form_Action_Google_Sheets_V4();

			} else {

				self::dependency_error();

				if(isset($_GET['activate'])) { unset($_GET['activate']); }
			}
		}

		function activate() {

			if (!self::is_dependency_ok()) {

				self::dependency_error();
			}
		}

		// Check dependencies
		function is_dependency_ok() {

			if(!defined('WS_FORM_VERSION')) { return false; }

			return(

				is_plugin_active(self::WS_FORM_PRO_ID) &&
				(version_compare(WS_FORM_VERSION, self::WS_FORM_PRO_VERSION_MIN) >= 0)
			);
		}

		// Add error notice action - Pro
		function dependency_error() {

			// Show error notification
			add_action('after_plugin_row_' . plugin_basename(__FILE__), array($this, 'dependency_error_notification'), 10, 2);
		}

		// Dependency error - Notification
		function dependency_error_notification($file, $plugin) {

			// Checks
			if(!current_user_can('update_plugins')) { return; }
			if($file != plugin_basename(__FILE__)) { return; }

			// Build notice
			$dependency_notice = sprintf('<tr class="plugin-update-tr"><td colspan="3" class="plugin-update colspanchange"><div class="update-message notice inline notice-error notice-alt"><p>%s</p></div></td></tr>', sprintf(__('This add-on requires %s (version %s or later) to be installed and activated.', 'ws-form-google-sheets-v4'), '<a href="https://wsform.com?utm_source=ws_form_pro&utm_medium=plugins" target="_blank">WS Form PRO</a>', self::WS_FORM_PRO_VERSION_MIN));

			// Show notice
			echo $dependency_notice;
		}
	}

	$wsf_add_on_google_sheets = new WS_Form_Add_On_Google_Sheets_V4();	

	register_activation_hook(__FILE__, array($wsf_add_on_google_sheets, 'activate'));

	// This gets fired by WS Form when it is ready to register add-ons
	add_action('wsf_plugins_loaded', function() {

		class WS_Form_Action_Google_Sheets_V4 extends WS_Form_Action {

			public $id = 'googlesheetsv4';
			public $pro_required = true;
			public $label;
			public $label_action;
			public $events;
			public $multiple = true;
			public $configured = false;
			public $priority = 50;
			public $can_repost = true;
			public $form_add = false;
			public $record_label = 'Row';
			public $list_sub_modal_label = 'Select Sheet';

			// Licensing
			private $licensing;

			// Client
			private $client;

			// Service
			private $service_sheets;
			private $service_drive;

			// Config
			private $api_credentials;
			private $api_refresh_token;
			private $api_endpoint;
			public $list_id = false;
			public $list_sub_id = false;
			public $opt_in_field;
			public $field_mapping;
			public $file_object_url;
			public $meta_mapping_custom;

			// Constants
			const DRIVE_GET_PAGE_SIZE = 100;

			const WS_FORM_LICENSE_ITEM_ID = 4144;
			const WS_FORM_LICENSE_NAME = 'Google Sheets add-on for WS Form PRO';
			const WS_FORM_LICENSE_VERSION = '1.0.29';
			const WS_FORM_LICENSE_AUTHOR = 'WS Form';

			public function __construct($init = true) {

				require_once __DIR__ . '/composer/vendor/autoload.php';

				// Set label
				$this->label = __('Google Sheets', 'ws-form-google-sheets-v4');

				// Set label for actions pull down
				$this->label_action = __('Add to Google Sheets', 'ws-form-google-sheets-v4');

				// Events
				$this->events = array('submit');

				if($init) { self::init(); }

				// Load plugin level configuration
				self::load_config_plugin();

				if(!empty($this->api_credentials)) {

					try {

						// Client
						$this->client = new Google_Client();
						$this->client->setAccessToken($this->api_credentials);

						// Services
						$this->service_sheets = new Google_Service_Sheets($this->client);
						$this->service_drive = new Google_Service_Drive($this->client);

					} catch (Exception $e) {

						// Error setting up Google Client so reset API
						self::reset_api();
					}
				}
			}

			public function init() {

				// Register data source
				if(class_exists('WS_Form_Data_Source')) {

					require_once __DIR__ . '/includes/data-sources/class-ws-form-data-source-google-sheets.php';
				}

				// Register config filters
				add_filter('wsf_config_options', array($this, 'config_options'), 10, 1);
				add_filter('wsf_config_meta_keys', array($this, 'config_meta_keys'), 10, 2);
				add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'plugin_action_links'), 10, 1);
				add_action('wsf_settings', array($this, 'wsf_settings_access_token'), 10, 0);
				add_action('rest_api_init', array($this, 'rest_api_init'), 10, 0);

				// Add nag action
				add_action('wsf_nag', array($this, 'nag'));

				// Licensing
				$this->licensing = new WS_Form_Licensing(

					self::WS_FORM_LICENSE_ITEM_ID,
					$this->id,
					self::WS_FORM_LICENSE_NAME,
					self::WS_FORM_LICENSE_VERSION,
					self::WS_FORM_LICENSE_AUTHOR,
					__FILE__
				);
				$this->licensing->transient_check();
				add_action('admin_init', array($this->licensing, 'updater'));
				add_filter('wsf_settings_static', array($this, 'settings_static'), 10, 2);
				add_filter('wsf_settings_button', array($this, 'settings_button'), 10, 3);
				add_filter('wsf_settings_update_fields', array($this, 'settings_update_fields'), 10, 2);

				// Register action
				parent::register($this);
			}

			// Get license item ID
			public function get_license_item_id() {

				return self::WS_FORM_LICENSE_ITEM_ID;
			}

			// Settings page rendered, check for credentials
			public function wsf_settings_access_token() {

				// Read credentials
				$api_credentials_json = WS_Form_Common::get_query_var($this->id . '_credentials', false);
				if($api_credentials_json === false) { return false; }

				// Decode API credentials
				$api_credentials_object = json_decode($api_credentials_json);
				if(
					is_null($api_credentials_object) ||
					!is_object($api_credentials_object)
				) {
					return false;
				}

				// Convert object to array
				$api_credentials_array = (array) $api_credentials_object;

				// Check if refresh token provided
				if(
					!isset($api_credentials_array['refresh_token']) ||
					($api_credentials_array['refresh_token'] == '')
				) {

					// If no refresh token received, it suggests an error or existing connection and we should reset the API connection as we have no refresh token
					self::reset_api();

				} else {

					// Save credentials (Array of credentials)
					WS_Form_Common::option_set('action_' . $this->id . '_api_credentials', $api_credentials_array);

					// Save refresh token (String)
					WS_Form_Common::option_set('action_' . $this->id . '_api_refresh_token', $api_credentials_array['refresh_token']);
				}

				// Refresh
				$redirect_url = WS_Form_Common::get_admin_url('ws-form-settings', false, 'tab=action_' . $this->id);
				header('Location: ' . $redirect_url);
				exit;
			}

			// Check access token to see if it has expired
			public function access_token_check() {

				// Check if token expired
				if(!$this->client->isAccessTokenExpired()) { return true; }

				// Check API refresh token is valid
				if(empty($this->api_refresh_token)) { self::reset_api(); return true; }

				// Get new access token
				$path = 'google-sheets-v4?refresh_token=' . rawurlencode($this->api_refresh_token);

				// Get new access token and refresh token
				$api_response = parent::api_call('https://wsform.com/', $path, 'GET');

				// Check status code
				if($api_response['http_code'] == 200) { 

					// Process new access token
					$api_response_decoded = json_decode($api_response['response']);
					if(is_null($api_response_decoded)) {

						return self::error(__('Invalid API response data', 'ws-form-google-sheets-v4'));
					}

					// Save access token
					$api_credentials_json = parent::get_object_value($api_response_decoded, $this->id . '_credentials');
					if($api_credentials_json !== false) {

						// Decode API credentials
						$api_credentials_object = json_decode($api_credentials_json);
						if(
							is_null($api_credentials_object) ||
							!is_object($api_credentials_object)
						) {
							return false;
						}

						// Convert object to array
						$api_credentials_array = (array) $api_credentials_object;

						// Check that we received an access token
						if(
							!isset($api_credentials_array['refresh_token']) ||
							($api_credentials_array['refresh_token'] == '')
						) {
							return false;
						}

						// Save API credentials (Array of credentials)
						$this->api_credentials = $api_credentials_array;
						WS_Form_Common::option_set('action_' . $this->id . '_api_credentials', $this->api_credentials);

						// Set access token using API credentials
						$this->client->setAccessToken($this->api_credentials);

						// Save refresh token (String)
						$this->api_refresh_token = $api_credentials_array['refresh_token'];
						WS_Form_Common::option_set('action_' . $this->id . '_api_refresh_token', $this->api_refresh_token);
					}
				}
			}

			// Plugin action link
			public function plugin_action_links($links) {

				// Settings
				array_unshift($links, sprintf('<a href="%s">%s</a>', WS_Form_Common::get_admin_url('ws-form-settings', false, 'tab=action_' . $this->id), __('Settings', 'ws-form')));

				return $links;
			}

			// Settings - Static
			public function settings_static($value, $field) {

				switch ($field) {

					case 'action_' . $this->id . '_license_version' :

						$value = self::WS_FORM_LICENSE_VERSION;
						break;

					case 'action_' . $this->id . '_license_status' :

						$value = $this->licensing->license_status();
						break;

					case 'action_' . $this->id . '_status' :

						$value = $this->configured ? 'Connected' : 'Disconnected';
						break;
				}

				return $value;
			}

			// Settings - Button
			public function settings_button($value, $field, $button) {

				switch($button) {

					case 'license_action_' . $this->id :

						$license_activated = WS_Form_Common::option_get('action_' . $this->id . '_license_activated', false);
						if($license_activated) {

							$value = '<input class="wsf-button" type="button" data-action="wsf-mode-submit" data-mode="deactivate" value="' . __('Deactivate', 'ws-form-google-sheets-v4') . '" />';

						} else {

							$value = '<input class="wsf-button" type="button" data-action="wsf-mode-submit" data-mode="activate" value="' . __('Activate', 'ws-form-google-sheets-v4') . '" />';
						}

						break;

					case 'oauth_action_' . $this->id :

						if($this->configured) {

							$value = '<input class="wsf-button wsf-button-inline" type="button" data-action="wsf-mode-submit" data-mode="access_token_delete" value="' . __('Disconnect', 'ws-form-google-sheets-v4') . '" />';

						} else {

							// Build query string
							$button_url = 'https://wsform.com/google-sheets-v4';
							$button_query_string = 'referrer=' . urlencode(WS_Form_Common::get_current_url());
							$button_url = WS_Form_Common::add_query_string($button_url, $button_query_string);

							$value = sprintf('<a href="%s"><img src="%simages/btn_google_signin_dark_normal_web@2x.png" alt="%s" style="width:191px];height:46px;vertical-align:middle;margin:0 0 0 6px" /></a>', $button_url, plugin_dir_url(__FILE__), __('Sign in with Google', 'ws-form-google-drive-v3'));
						}

						break;
				}
				
				return $value;
			}

			// Settings - Update fields
			public function settings_update_fields($field, $value) {

				switch ($field) {

					case 'action_' . $this->id . '_license_key' :

						$mode = WS_Form_Common::get_query_var('action_mode');

						switch($mode) {

							case 'activate' :

								$this->licensing->activate($value);
								break;

							case 'deactivate' :

								$this->licensing->deactivate($value);
								break;

							case 'access_token_delete' :

								self::reset_api();
								break;
						}

					break;
				}
			}

			// Reset API
			public function reset_api() {

				// Revoke token
				if(
					is_array($this->api_credentials) &&
					isset($this->api_credentials['access_token']) &&
					!empty($this->api_credentials['access_token'])
				) {
					self::revoke_access_token($this->api_credentials['access_token']);
				}

				WS_Form_Common::option_set('action_' . $this->id . '_api_credentials', '');
				WS_Form_Common::option_set('action_' . $this->id . '_api_refresh_token', '');
			}

			// Revoke access token
			public function revoke_access_token($access_token) {

				// Check token
				if(!is_string($access_token)) { return false; }

				// Revoke access token
				$path = '/google-sheets-v4?revoke_access_token=' . rawurlencode($access_token);
				$api_response = parent::api_call('https://wsform.com/', $path, 'GET');
			}

			// Nag
			public function nag() {

				// Load plugin level configuration
				self::load_config_plugin();

				if(!$this->configured) {

					WS_Form_Common::admin_message_push(sprintf(__('To complete the %s setup for %s, please connect your Google Sheets account  <a href="%s">here</a>.', 'ws-form-google-sheets-v4'), $this->label, WS_FORM_NAME_PRESENTABLE, WS_Form_Common::get_admin_url('ws-form-settings', -1, 'tab=action_' . $this->id)), 'notice-warning', false);
				}
			}

			// Post to API
			public function post($form, &$submit, $config) {

				// Check action is configured properly
				if(!self::check_configured()) { return false; }

				// Load configuration
				self::load_config($config);

				// Check access token
				self::access_token_check();

				// Check list ID is configured properly
				if(!self::check_list_id()) { return false; }

				// Check list sub ID is configured properly
				if(!self::check_list_sub_id()) { return false; }

				// Opt-In Check
				$opted_in = false;

				// Get opt in value (False if field not submitted)
				$opt_in_field_value = parent::get_submit_value($submit, WS_FORM_FIELD_PREFIX . $this->opt_in_field, false);

				if(($this->opt_in_field !== false) && ($this->opt_in_field !== '') && ($opt_in_field_value !== false)) {

					// End user did not opt in, exit gracefully
					if(empty($opt_in_field_value)) {

						self::success(__('User did not opt in, no data pushed to action', 'ws-form-google-sheets-v4'));
						return true;

					} else {

						$opted_in = true;
					}
				}

				// Get current column headings
				try {

					$list_sub_label = self::get_list_sub_label();
					if($list_sub_label === false) { return false; }

					$range = $list_sub_label . '!1:1';

					$response = $this->service_sheets->spreadsheets_values->get($this->list_id, $range);

					$columns = $response->getValues();

				} catch (\Google_Service_Exception $e) {

					return self::error(self::get_api_error_detail($e->getMessage()));
				}

				if(!isset($columns[0])) { return false; }

				// Process field mapping
				$field_map_cache = array();
				foreach($this->field_mapping as $field_map) {

					$field_id = $field_map['ws_form_field'];
					$submit_sub_type = false;
					$submit_format_date = false;
					$submit_format_time = false;

					$api_field_string = $field_map['action_' . $this->id . '_list_fields'];

					// Get submit value
					$submit_value = parent::get_submit_value($submit, WS_FORM_FIELD_PREFIX . $field_id, false);
					if($submit_value === false) { continue; }
					$submit_value = WS_Form_Common::parse_variables_process($submit_value, $form, $submit, 'text/plain');

					// Get submit type
					$submit_type = parent::get_submit_type($submit, WS_FORM_FIELD_PREFIX . $field_id, false);
					if($submit_type === false) { continue; }

					// Get sub type and date formatting
					if($field_id > 0) {

						$ws_form_field = new WS_Form_Field();
						$ws_form_field->id = $field_id;
						$field_object = $ws_form_field->db_read(true, true);
						$submit_sub_type = WS_Form_Common::get_object_meta_value($field_object, 'input_type_datetime');
						$submit_format_date = WS_Form_Common::get_object_meta_value($field_object, 'format_date');
						if($submit_format_date == '') { $submit_format_date = get_option('date_format'); }
						$submit_format_time = WS_Form_Common::get_object_meta_value($field_object, 'format_time');
						if($submit_format_time == '') { $submit_format_time = get_option('time_format'); }
					}

					// Store to cache
					$field_map_cache[$api_field_string] = array(

						'id' => $field_id,
						'value' => $submit_value,
						'type' => $submit_type,
						'sub_type' => $submit_sub_type,
						'format_date' => $submit_format_date,
						'format_time' => $submit_format_time
					);
				}

				// Process custom meta mapping
				foreach($this->meta_mapping_custom as $meta_map) {

					// Defaults
					$type = 'text';
					$sub_type = false;

					// Get value
					$meta_value = $meta_map['action_' . $this->id . '_meta_value'];
					$meta_value = WS_Form_Common::parse_variables_process($meta_value, $form, $submit, 'text/plain');

					// Get column name
					$api_field_string = $meta_map['action_' . $this->id . '_list_fields'];
					if(empty($api_field_string)) { continue; }

					// Get format
					$format = $meta_map['action_' . $this->id . '_format'];
					switch($format) {

						case 'datetime' :

							$type = 'datetime';
							$sub_type = 'datetime-local';
							break;

						case 'date' :

							$type = 'datetime';
							$sub_type = 'date';
							break;

						case 'time' :

							$type = 'datetime';
							$sub_type = 'time';
							break;

						case 'number' :

							$type = 'number';
							break;

						case 'color' :

							$type = 'color';
							break;
					}

					// Store to cache
					$field_map_cache[$api_field_string] = array(

						'id' => 0,
						'value' => $meta_value,
						'type' => $type,
						'sub_type' => $sub_type,
						'format_date' => get_option('date_format'),
						'format_time' => get_option('time_format')
					);
				}

				// Build append array
				$values = array();

				foreach($columns[0] as $column_index => $column) {

					$column_value = '';
					$field_type = false;
					$field_sub_type = false;

					if(isset($field_map_cache[$column])) {

						$column_value = $field_map_cache[$column]['value'];
						$field_id = $field_map_cache[$column]['id'];
						$field_type = $field_map_cache[$column]['type'];
						$field_sub_type = $field_map_cache[$column]['sub_type'];
					}

					// Push blank columns as text
					if($column_value == '') { $field_type = 'text'; }

					$value = array();

					// Process by field type
					switch($field_type) {

						// Signatures / Files
						case 'signature' :
						case 'file' :

							if(!is_array($column_value)) { break; }

							$column_value_filenames = array();

							foreach($column_value as $file_object_index => $file_object) {

								if($this->file_object_url) {

									// Use file URL

									// Get handler
									$handler = isset($file_object['handler']) ? $file_object['handler'] : 'wsform';

									// Get URL
									$file_urls = array();
									if(isset(WS_Form_File_Handler_WS_Form::$file_handlers[$handler])) {

										$file_url = WS_Form_File_Handler_WS_Form::$file_handlers[$handler]->get_url($file_object, $field_id, $file_object_index, $submit->hash);
										$endpoint_value[$file_object_index]['url'] = $file_url;
										$file_urls[] = $file_url;
									}

									$column_value_filenames[] = implode(',', $file_urls);

								} else {

									// Use file name
									$column_value_filenames[] = $file_object['name'];
								}
							}

							// Get file name(s)
							$file_names = implode(',', $column_value_filenames);

							if($this->file_object_url && (count($column_value_filenames) === 1)) {

								// If single file and using URL's, add hyperlink formula
								$value['userEnteredValue'] = array('formulaValue' => sprintf('=HYPERLINK("%s")', $file_names));

							} else {

								// If not using URLs, add as file name string
								$value['userEnteredValue'] = array('stringValue' => $file_names);
							}

							break;

						// Date
						case 'datetime' :

			 				// Get date format from field
							$date_format = $field_map_cache[$column]['format_date'];
							$google_date_format = str_replace('d', 'dd', $date_format);
							$google_date_format = str_replace('m', 'mm', $google_date_format);
							$google_date_format = str_replace('F', 'mmmm', $google_date_format);
							$google_date_format = str_replace('j', 'd', $google_date_format);
							$google_date_format = str_replace('Y', 'yyyy', $google_date_format);

							// Get time format from field
							$time_format = $field_map_cache[$column]['format_time'];
							$google_time_format = str_replace('H', 'hh', $time_format);
							$google_time_format = str_replace('g', 'h', $google_time_format);
							$google_time_format = str_replace('i', 'mm', $google_time_format);
							$google_time_format = str_replace('a', 'am/pm', $google_time_format);
							$google_time_format = str_replace('A', 'am/pm', $google_time_format);

							switch($field_sub_type) {

								// Week
								case 'week' :

									// Do nothing, leave as string
									break;

								// Month
								case 'month' :

									$date_parsed = date_parse_from_format('F Y', $column_value);
									if($date_parsed['error_count'] > 0) { break; }
									$epoch_time = mktime(

										0, 
										0, 
										0, 
										$date_parsed['month'], 
										1, 
										$date_parsed['year']
									);
									$date_google = 25569 + ($epoch_time / 86400);

									$value['userEnteredValue'] = array('numberValue' => $date_google);
									$value['userEnteredFormat'] = array('numberFormat' => array('type' => 'DATE', 'pattern' => 'mmmm yyyy'));
									break;

								// Date / Time
								case 'datetime-local' :

									$date_parsed = date_parse_from_format($date_format . ' ' . $time_format, $column_value);
									if($date_parsed['error_count'] > 0) { break; }

									$epoch_time = mktime(

										$date_parsed['hour'], 
										$date_parsed['minute'], 
										$date_parsed['second'], 
										$date_parsed['month'], 
										$date_parsed['day'], 
										$date_parsed['year']
									);
									$date_google = 25569 + ($epoch_time / 86400);

									$value['userEnteredValue'] = array('numberValue' => $date_google);
									$value['userEnteredFormat'] = array('numberFormat' => array('type' => 'DATE', 'pattern' => $google_date_format . ' ' . $google_time_format));
									break;

								// Time
								case 'time' :

									$date_parsed = date_parse_from_format($time_format, $column_value);
									if($date_parsed['error_count'] > 0) { break; }

									$epoch_time = mktime(

										$date_parsed['hour'], 
										$date_parsed['minute'], 
										$date_parsed['second'], 
										1, 
										1, 
										1970
									);
									$date_google = ($epoch_time / 86400);

									$value['userEnteredValue'] = array('numberValue' => $date_google);
									$value['userEnteredFormat'] = array('numberFormat' => array('type' => 'DATE', 'pattern' => $google_time_format));
									break;

								// Date
								default:

									$date_parsed = date_parse_from_format($date_format, $column_value);
									if($date_parsed['error_count'] > 0) { break; }

									$epoch_time = mktime(

										$date_parsed['hour'], 
										$date_parsed['minute'], 
										$date_parsed['second'], 
										$date_parsed['month'], 
										$date_parsed['day'], 
										$date_parsed['year']
									);
									$date_google = 25569 + ($epoch_time / 86400);

									$value['userEnteredValue'] = array('numberValue' => $date_google);
									$value['userEnteredFormat'] = array('numberFormat' => array('type' => 'DATE', 'pattern' => $google_date_format));

							}

							break;

						// Number
						case 'number' :
						case 'range' :
						case 'rating' :

							if(!is_numeric($column_value)) { break; }

							$value['userEnteredValue'] = array('numberValue' => $column_value);
							$value['userEnteredFormat'] = array('numberFormat' => array('type' => 'NUMBER'));

							break;

						// Color
						case 'color' :

							$background_color = self::hex_to_rgb($column_value);
							$hsl = self::hex_to_hsl($column_value);
							$l = $hsl[2];

							if($l > 0.5) {

								$foreground_color = array('red' => 0, 'green' => 0, 'blue' => 0);

							} else {

								$foreground_color = array('red' => 1, 'green' => 1, 'blue' => 1);
							}

							if($background_color !== false) {

								$value['userEnteredFormat'] = array('backgroundColor' => $background_color, 'textFormat' => array('foregroundColor' => $foreground_color));
							}

							break;

					}

					if(empty($value)) {

						$value['userEnteredValue'] = array('stringValue' => is_array($column_value) ? implode(',', $column_value) : $column_value);
					}

					$values[] = $value;
				}

				$request_body_array = array(

					'requests' => array(

						// Request 1
						array(

							'appendCells' => array(

								'sheetId' => $this->list_sub_id,
								'rows' => array(array('values' => $values)),
								'fields' => '*'
							)
						)
					)
				);

				// Build request body
				$request_body = new Google_Service_Sheets_BatchUpdateSpreadsheetRequest($request_body_array);

				try {

					// Update the spreadsheet
					$this->service_sheets->spreadsheets->batchUpdate($this->list_id, $request_body);

					self::success(sprintf(__('Successfully added to spreadsheet: %s (Sheet: %u)', 'ws-form-google-sheets-v4'), $this->list_id, $this->list_sub_id));
							return true;

				} catch (\Google_Service_Exception $e) {

					return self::error(self::get_api_error_detail($e->getMessage()));
				}
			}

			// Get sheet for data source
			public function get_sheet() {

				// Check action is configured properly
				if(!self::check_configured()) { return false; }

				// Check access token
				self::access_token_check();

				// Check list ID is configured properly
				if(!self::check_list_id()) { return false; }

				// Check list sub ID is configured properly
				if(!self::check_list_sub_id()) { return false; }

				$spreadsheet = $this->service_sheets->spreadsheets->get($this->list_id);

				$sheets = $spreadsheet->getSheets();

				$sheet = false;

				foreach($sheets as $sheet_single) {

					$sheet_id = $sheet_single->getProperties()->getSheetId();

					if($sheet_id == $this->list_sub_id) {

						$sheet = $sheet_single;
					}
				}

				if($sheet === false) { return false; }

				$sheet_title = $sheet->getProperties()->getTitle();

				$response = $this->service_sheets->spreadsheets_values->get($this->list_id, $sheet_title);
			    $values = $response->getValues();

				return $values;
			}

			// Get lists
			public function get_lists($fetch = false) {

				// Check action is configured properly
				if(!self::check_configured()) { return false; }

				// Check access token
				self::access_token_check();

				// Check to see if lists are cached
				$lists = WS_Form_Common::option_get('action_' . $this->id . '_lists');

				// Retried if fetch is requested or lists are not cached
				if($fetch || ($lists === false)) {

					$lists = array();

					// Initialize
					$next_page_token = false;

					do {

						$params = array(

							'q' 		=> "mimeType='application/vnd.google-apps.spreadsheet' and trashed = false",
							'pageSize' 	=> self::DRIVE_GET_PAGE_SIZE,
							'fields' 	=> 'nextPageToken, files(id, name)'
						);

						if($next_page_token !== false) {

							$params['pageToken'] = $next_page_token;
						}

						try {

							$files = $this->service_drive->files->listFiles($params);

						} catch (\Google_Service_Exception $e) {

							return self::error(self::get_api_error_detail($e->getMessage()));
						}

						// Check for next page token
						if(isset($files->nextPageToken)) {

							$next_page_token = $files->nextPageToken;

						} else {

							$next_page_token = false;
						}

						// Check for files
						if(isset($files->files)) { $files = $files->files; } else { return false; }

						foreach($files as $file) {

							$lists[] = array(

								'id' => 			$file['id'], 
								'label' => 			$file['name'], 
								'field_count' => 	false, 
								'record_count' => 	false,
								'list_sub' =>		true
							);
						}

					} while ($next_page_token !== false);

					// Store to options
					WS_Form_Common::option_set('action_' . $this->id . '_lists', $lists);
				}

				return $lists;
			}

			// Get list subs
			public function get_list_subs($fetch = false) {

				// Check action is configured properly
				if(!self::check_configured()) { return false; }

				// Check list ID is set
				if(!self::check_list_id()) { return false; }

				// Check access token
				self::access_token_check();

				// Check to see if list_subs are cached
				$list_subs = WS_Form_Common::option_get('action_' . $this->id . '_list_subs_' . $this->list_id);

				// Retried if fetch is requested or list_subs are not cached
				if($fetch || ($list_subs === false)) {

					$list_subs = array();

					try {

						$sheet = $this->service_sheets->spreadsheets->get($this->list_id);;

					} catch (\Google_Service_Exception $e) {

						return self::error(self::get_api_error_detail($e->getMessage()));
					}

					$sheets = $sheet->getSheets();

					foreach($sheets as $sheet) {

						$list_subs[] = array(

							'id' => 			$sheet['properties']['sheetId'], 
							'label' => 			$sheet['properties']['title'],
							'record_count' =>	$sheet['properties']['gridProperties']['rowCount']
						);
					}

					// Store to options
					WS_Form_Common::option_set('action_' . $this->id . '_list_subs_' . '_' . $this->list_id, $list_subs);
				}

				return $list_subs;
			}

			// Get list
			public function get_list($fetch = false) {

				// Check action is configured properly
				if(!self::check_configured()) { return false; }

				// Check list ID is set
				if(!self::check_list_id()) { return false; }

				// Check list sub ID is set
				if(!self::check_list_sub_id()) { return false; }

				// Build list
				$list = array(

					'label' => self::get_list_sub_label()
				);

				return $list;
			}

			// Get list fields
			public function get_list_fields($fetch = false) {

				// Check action is configured properly
				if(!self::check_configured()) { return false; }

				// Check list ID is set
				if(!self::check_list_id()) { return false; }

				// Check access token
				self::access_token_check();

				$list_fields = WS_Form_Common::option_get('action_' . $this->id . '_list_fields_' . $this->list_id . '_' . $this->list_sub_id);

				if($fetch || ($list_fields === false)) {

					$list_fields = array();

					try {

						$range = self::get_list_sub_label() . '!1:1';

						$response = $this->service_sheets->spreadsheets_values->get($this->list_id, $range);

						$columns = $response->getValues();

					} catch (\Google_Service_Exception $e) {

						return self::error(self::get_api_error_detail($e->getMessage()));
					}

					if(!isset($columns[0])) { return false; }

					$column_index = 0;

					foreach($columns[0] as $column_index => $column_title) {

						// Check for blank column names
						if($column_title == '') { $column_title = sprintf(__('Column %u', 'ws-form-google-sheets-v4'), $column_index + 1); }

						// Add column
						$list_fields[] = array(

							'id' => 			$column_title, 
							'id_sub' =>			false,
							'label' => 			$column_title, 
							'label_field' => 	$column_title, 
							'label_sub' =>		false,
							'type' => 			'text', 
							'required' => 		false, 
							'default_value' => 	'', 
							'pattern' => 		false, 
							'placeholder' => 	false, 
							'input_mask' =>		false,
							'help' => 			'', 
							'sort_index' => 	$column_index,
							'visible' =>		true
						);

						$column_index++;
					}

					// Store to options
					WS_Form_Common::option_set('action_' . $this->id . '_list_fields_' . $this->list_id . '_' . $this->list_sub_id, $list_fields);
				}

				return $list_fields;
			}

			// Get form fields
			public function get_fields() {

				$form_fields = array(

					'opt_in_field' => array(

						'type'	=>	'checkbox',
						'label'	=>	__('Opt-In', 'ws-form'),
						'meta'	=>	array(

							'data_grid_checkbox' => WS_Form_Common::build_data_grid_meta('data_grid_checkbox', false, false, array(

								array(

									'id'		=> 1,
									'default'	=> '',
									'required'	=> '',
									'disabled'	=> '',
									'hidden'	=> '',
									'data'		=> array(__('I consent to #blog_name storing my submitted information', 'ws-form'))
								)
							))
						)
					),

					'submit' => array(

						'type'			=>	'submit',
						'width_factor'	=>	0.5
					),

					'reset' => array(

						'type'			=>	'reset',
						'width_factor'	=>	0.5
					),
				);

				return $form_fields;
			}

			// Get form actions
			public function get_actions() {

				$form_actions = array(

					$this->id => array(

						'meta'	=> array(

							'action_' . $this->id . '_list_id'			=>	$this->list_id,
							'action_' . $this->id . '_list_sub_id'		=>	$this->list_sub_id,
							'action_' . $this->id . '_field_mapping'	=>	'field_mapping',
							'action_' . $this->id . '_opt_in_field'		=>	'opt_in_field',
						)
					),

					'message',

					'database'
				);

				return $form_actions;
			}

			// Get API error detail
			public function get_api_error_detail($api_response) {

				$api_response_decoded = json_decode($api_response);
				if(is_null($api_response_decoded)) { return __('Unknown API error for action: ' . $this->label, 'ws-form-google-sheets-v4'); }
				if(!isset($api_response_decoded->error)) { return __('Unknown API error for action: ' . $this->label, 'ws-form-google-sheets-v4'); }
				if(!isset($api_response_decoded->error->errors)) { return __('Unknown API error for action: ' . $this->label, 'ws-form-google-sheets-v4'); }

				// Get error title from JSON response
				$error_detail_array = array();
				foreach($api_response_decoded->error->errors as $error) {

					$error_detail_array[] = $error->message;
				}

				return implode(', ', $error_detail_array);
			}

			// Get settings
			public function get_action_settings() {

				$settings = array(

					'meta_keys'		=> array(

						'action_' . $this->id . '_list_id',
						'action_' . $this->id . '_list_sub_id',
						'action_' . $this->id . '_opt_in_field',
						'action_' . $this->id . '_field_mapping',
						'action_' . $this->id . '_file_object_url',
						'action_' . $this->id . '_meta_mapping_custom'
					)
				);

				// Wrap settings so they will work with sidebar_html function in admin.js
				$settings = parent::get_settings_wrapper($settings);

				// Add labels
				$settings->label = $this->label;
				$settings->label_action = $this->label_action;

				// Add multiple
				$settings->multiple = $this->multiple;

				// Add events
				$settings->events = $this->events;

				// Add can_repost
				$settings->can_repost = $this->can_repost;

				// Apply filter
				$settings = apply_filters('wsf_action_' . $this->id . '_settings', $settings);

				return $settings;
			}

			// Get list sub label (Sheet name)
			public function get_list_sub_label() {

				// Check list ID is set
				if(!self::check_list_id()) { return false; }

				// Check list sub ID is set
				if(!self::check_list_sub_id()) { return false; }

				$list_subs = self::get_list_subs();

				if($list_subs === false) { return false; }

				foreach($list_subs as $list_sub) {

					if($list_sub['id'] == $this->list_sub_id) { return $list_sub['label']; }
				}

				return __('Unknown', 'ws-form-google-sheets-v4');
			}

			// Check action is configured properly
			public function check_configured() {

				if(!$this->configured) { return self::error(__('Action not configured', 'ws-form-google-sheets-v4') . ' (' . $this->label . ')'); }

				return $this->configured;
			}

			// Check list ID is set
			public function check_list_id() {

				if($this->list_id === false) { return self::error(__('List ID is not set', 'ws-form-google-sheets-v4')); }

				return ($this->list_id !== false);
			}

			// Check list sub ID is set
			public function check_list_sub_id() {

				if($this->list_sub_id === false) { return self::error(__('List sub ID is not set', 'ws-form-google-sheets-v4')); }

				return ($this->list_sub_id !== false);
			}

			// Meta keys for this action
			public function config_meta_keys($meta_keys = array(), $form_id = 0) {

				// Build config_meta_keys
				$config_meta_keys = array(

					// List ID
					'action_' . $this->id . '_list_id'	=> array(

						'label'						=>	__('File', 'ws-form-google-sheets-v4'),
						'type'						=>	'select',
						'help'						=>	__('Select the Google Sheets file to associate this form with.', 'ws-form-google-sheets-v4'),
						'options'						=>	'action_api_populate',
						'options_blank'					=>	__('Select...', 'ws-form-google-sheets-v4'),
						'options_action_id_meta_key'	=>	'action_id',
						'options_action_api_populate'	=>	'lists',
						'reload'					=>	array(

							'action_id'			=>	$this->id,
							'method'			=>	'lists_fetch'
						),
					),

					// List sub ID
					'action_' . $this->id . '_list_sub_id'	=> array(

						'label'						=>	__('Sheet', 'ws-form-google-sheets-v4'),
						'type'						=>	'select',
						'help'						=>	__('Select the sheet to associate this form with.', 'ws-form-google-sheets-v4'),
						'options'						=>	'action_api_populate',
						'options_blank'					=>	__('Select...', 'ws-form-google-sheets-v4'),
						'options_action_id_meta_key'	=>	'action_id',
						'options_list_id_meta_key'		=>	'action_' . $this->id . '_list_id',
						'options_action_api_populate'	=>	'list_subs',
						'reload'					=>	array(

							'action_id'			=>	$this->id,
							'method'			=>	'list_subs_fetch',
							'list_id_meta_key'	=>	'action_' . $this->id . '_list_id'
						),
						'condition'						=>	array(

							array(

								'logic'			=>	'!=',
								'meta_key'		=>	'action_' . $this->id . '_list_id',
								'meta_value'	=>	''
							)
						)
					),

					// Opt-In field
					'action_' . $this->id . '_opt_in_field'	=> array(

						'label'							=>	__('Opt-In Field', 'ws-form-google-sheets-v4'),
						'type'							=>	'select',
						'options'						=>	'fields',
						'options_blank'					=>	__('Select...', 'ws-form-google-sheets-v4'),
						'fields_filter_type'			=>	array('select', 'checkbox', 'radio'),
						'help'							=>	__('Checkbox recommended', 'ws-form-google-sheets-v4'),
						'condition'						=>	array(

							array(

								'logic'			=>	'!=',
								'meta_key'		=>	'action_' . $this->id . '_list_id',
								'meta_value'	=>	''
							),

							array(

								'logic_previous'	=>	'&&',
								'logic'				=>	'!=',
								'meta_key'			=>	'action_' . $this->id . '_list_sub_id',
								'meta_value'		=>	''
							)
						)
					),

					// Field mapping
					'action_' . $this->id . '_field_mapping'	=> array(

						'label'						=>	__('Field Mapping', 'ws-form-google-sheets-v4'),
						'type'						=>	'repeater',
						'help'						=>	__('Map WS Form fields to Google Sheets merge fields.', 'ws-form-google-sheets-v4'),
						'meta_keys'					=>	array(

							'ws_form_field',
							'action_' . $this->id . '_list_fields'
						),
						'meta_keys_unique'			=>	array(

							'action_' . $this->id . '_list_fields'
						),
						'reload'					=>	array(

							'action_id'				=>	$this->id,
							'method'				=>	'list_fields_fetch',
							'list_id_meta_key'		=>	'action_' . $this->id . '_list_id',
							'list_sub_id_meta_key'	=>	'action_' . $this->id . '_list_sub_id'
						),
						'auto_map'					=>	true,
						'condition'					=>	array(

							array(

								'logic'			=>	'!=',
								'meta_key'		=>	'action_' . $this->id . '_list_id',
								'meta_value'	=>	''
							),

							array(

								'logic_previous'	=>	'&&',
								'logic'				=>	'!=',
								'meta_key'			=>	'action_' . $this->id . '_list_sub_id',
								'meta_value'		=>	''
							)
						)
					),

					// Opt-In field
					'action_' . $this->id . '_file_object_url'	=> array(

						'label'							=>	__('Use URL for File Fields', 'ws-form-google-sheets-v4'),
						'type'							=>	'checkbox',
						'help'							=>	__('If checked, mapped file and signature fields will be populated with URLs instead of the file name.', 'ws-form-google-sheets-v4'),
						'condition'						=>	array(

							array(

								'logic'			=>	'!=',
								'meta_key'		=>	'action_' . $this->id . '_list_id',
								'meta_value'	=>	''
							),

							array(

								'logic_previous'	=>	'&&',
								'logic'				=>	'!=',
								'meta_key'			=>	'action_' . $this->id . '_list_sub_id',
								'meta_value'		=>	''
							)
						)
					),

					// Custom meta mapping
					'action_' . $this->id . '_meta_mapping_custom'	=> array(

						'label'						=>	__('Custom Mapping', 'ws-form-post'),
						'type'						=>	'repeater',
						'help'						=>	__('Map custom values to Google Sheets columns.', 'ws-form-post'),
						'meta_keys'					=>	array(

							'action_' . $this->id . '_meta_value',
							'action_' . $this->id . '_list_fields',
							'action_' . $this->id . '_format',
						),
						'meta_keys_unique'			=>	array(

							'action_' . $this->id . '_list_fields'
						),
						'reload'					=>	array(

							'action_id'				=>	$this->id,
							'method'				=>	'list_fields_fetch',
							'list_id_meta_key'		=>	'action_' . $this->id . '_list_id',
							'list_sub_id_meta_key'	=>	'action_' . $this->id . '_list_sub_id'
						),
						'condition'						=>	array(

							array(

								'logic'			=>	'!=',
								'meta_key'		=>	'action_' . $this->id . '_list_id',
								'meta_value'	=>	''
							),

							array(

								'logic_previous'	=>	'&&',
								'logic'				=>	'!=',
								'meta_key'			=>	'action_' . $this->id . '_list_sub_id',
								'meta_value'		=>	''
							)
						)
					),

					// Meta value
					'action_' . $this->id . '_meta_value'	=> array(

						'label'						=>	__('Meta Value', 'ws-form-post'),
						'type'						=>	'text'
					),

					// Comment Status
					'action_' . $this->id . '_format'	=> array(

						'label'						=>	__('Format', 'ws-form-post'),
						'type'						=>	'select',
						'options'					=>	array(

							array('value' => 'text', 'text' => 'Text'),
							array('value' => 'datetime', 'text' => 'Date/Time'),
							array('value' => 'date', 'text' => 'Date'),
							array('value' => 'time', 'text' => 'Time'),
							array('value' => 'number', 'text' => 'Number'),
							array('value' => 'color', 'text' => 'Color')
						),
						'default'					=>	'text'
					),

					// List fields
					'action_' . $this->id . '_list_fields'	=> array(

						'label'							=>	__('Google Sheets Column', 'ws-form-google-sheets-v4'),
						'type'							=>	'select',
						'options'						=>	'action_api_populate',
						'options_blank'					=>	__('Select...', 'ws-form-google-sheets-v4'),
						'options_action_id'				=>	$this->id,
						'options_list_id_meta_key'		=>	'action_' . $this->id . '_list_id',
						'options_list_sub_id_meta_key'	=>	'action_' . $this->id . '_list_sub_id',
						'options_action_api_populate'	=>	'list_fields'
					)
				);

				// Merge
				$meta_keys = array_merge($meta_keys, $config_meta_keys);

				return $meta_keys;
			}

			// Plug-in options for this action
			public function config_options($options) {

				$options['action_' . $this->id] = array(

					'label'		=>	$this->label,
					'fields'	=>	array(

						'action_' . $this->id . '_license_version'	=>	array(

							'label'		=>	__('Add-on Version', 'ws-form-google-sheets-v4'),
							'type'		=>	'static'
						),

						'action_' . $this->id . '_license_key'	=>	array(

							'label'		=>	__('Add-on License Key', 'ws-form-google-sheets-v4'),
							'type'		=>	'text',
							'help'		=>	__('Enter your Google Sheets add-on for WS Form PRO license key here.', 'ws-form-google-sheets-v4'),
							'button'	=>	'license_action_' . $this->id,
							'action'	=>	$this->id
						),

						'action_' . $this->id . '_license_status'	=>	array(

							'label'		=>	__('Add-on License Status', 'ws-form-google-sheets-v4'),
							'type'		=>	'static'
						),

						'action_' . $this->id . '_status'	=>	array(

							'label'			=>	__('Google Sheets Status', 'ws-form-google-sheets-v4'),
							'type'			=>	'static',
							'button'		=>	'oauth_action_' . $this->id,
						)
					)
				);

				return $options;
			}

			// Load config for this action
			public function load_config($config = array()) {

				$this->list_id = parent::get_config($config, 'action_' . $this->id . '_list_id');
				$this->list_sub_id = parent::get_config($config, 'action_' . $this->id . '_list_sub_id');
				$this->opt_in_field = parent::get_config($config, 'action_' . $this->id . '_opt_in_field');

				// Field Mapping
				$this->field_mapping = parent::get_config($config, 'action_' . $this->id . '_field_mapping', array());
				if(!is_array($this->field_mapping)) { $this->field_mapping = array(); }

				$this->file_object_url = parent::get_config($config, 'action_' . $this->id . '_file_object_url');

				// Custom meta mapping
				$this->meta_mapping_custom = parent::get_config($config, 'action_' . $this->id . '_meta_mapping_custom', array());
				if(!is_array($this->meta_mapping_custom)) { $this->meta_mapping_custom = array(); }
			}

			// Load config at plugin level
			public function load_config_plugin() {

				$this->configured = false;

				$this->api_credentials = WS_Form_Common::option_get('action_' . $this->id . '_api_credentials', '');
				$this->api_refresh_token = WS_Form_Common::option_get('action_' . $this->id . '_api_refresh_token', '');

				if(!empty($this->api_credentials) && !empty($this->api_refresh_token)) {

					$this->configured = true;

					// Check API credentials (Legacy data format)
					if(!is_array($this->api_credentials)) {

						$api_credentials_json = $this->api_credentials;
						$api_credentials_object = json_decode($api_credentials_json);

						if(
							!is_null($api_credentials_object) &&
							is_object($api_credentials_object)
						) {

							// Convert credentials to array
							$api_credentials_array = (array) $api_credentials_object;

							// Save credentials
							WS_Form_Common::option_set('action_' . $this->id . '_api_credentials', $api_credentials_array);

							// Set credentials
							$this->api_credentials = $api_credentials_array;
						}
					}		
				}

				return $this->configured;
			}

			// Build REST API endpoints
			public function rest_api_init() {

				// API routes - get_* (Use cache)
				register_rest_route(WS_FORM_RESTFUL_NAMESPACE, '/action/' . $this->id . '/lists/', array('methods' => 'GET', 'callback' => array($this, 'api_get_lists'), 'permission_callback' => function () { return WS_Form_Common::can_user('create_form'); }));
				register_rest_route(WS_FORM_RESTFUL_NAMESPACE, '/action/' . $this->id . '/list/(?P<list_id>[a-zA-Z0-9-_]+)/', array('methods' => 'GET', 'callback' => array($this, 'api_get_list'), 'permission_callback' => function () { return WS_Form_Common::can_user('create_form'); }));
				register_rest_route(WS_FORM_RESTFUL_NAMESPACE, '/action/' . $this->id . '/list/(?P<list_id>[a-zA-Z0-9-_]+)/subs/', array('methods' => 'GET', 'callback' => array($this, 'api_get_list_subs'), 'permission_callback' => function () { return WS_Form_Common::can_user('create_form'); }));
				register_rest_route(WS_FORM_RESTFUL_NAMESPACE, '/action/' . $this->id . '/list/(?P<list_id>[a-zA-Z0-9-_]+)/subs/(?P<list_sub_id>[a-zA-Z0-9-_]+)/fields/', array('methods' => 'GET', 'callback' => array($this, 'api_get_list_fields'), 'permission_callback' => function () { return WS_Form_Common::can_user('create_form'); }));

				// API routes - fetch_* (Pull from API and update cache)
				register_rest_route(WS_FORM_RESTFUL_NAMESPACE, '/action/' . $this->id . '/lists/fetch/', array('methods' => 'GET', 'callback' => array($this, 'api_fetch_lists'), 'permission_callback' => function () { return WS_Form_Common::can_user('create_form'); }));
				register_rest_route(WS_FORM_RESTFUL_NAMESPACE, '/action/' . $this->id . '/list/(?P<list_id>[a-zA-Z0-9-_]+)/fetch/', array('methods' => 'GET', 'callback' => array($this, 'api_fetch_list'), 'permission_callback' => function () { return WS_Form_Common::can_user('create_form'); }));
				register_rest_route(WS_FORM_RESTFUL_NAMESPACE, '/action/' . $this->id . '/list/(?P<list_id>[a-zA-Z0-9-_]+)/subs/fetch/', array('methods' => 'GET', 'callback' => array($this, 'api_fetch_list_subs'), 'permission_callback' => function () { return WS_Form_Common::can_user('create_form'); }));
				register_rest_route(WS_FORM_RESTFUL_NAMESPACE, '/action/' . $this->id . '/list/(?P<list_id>[a-zA-Z0-9-_]+)/subs/(?P<list_sub_id>[a-zA-Z0-9-_]+)/fields/fetch/', array('methods' => 'GET', 'callback' => array($this, 'api_fetch_list_fields'), 'permission_callback' => function () { return WS_Form_Common::can_user('create_form'); }));
			}

			// API endpoint - Lists
			public function api_get_lists() {

				// Get lists
				$lists = self::get_lists();

				// Process response
				self::api_response($lists);
			}

			// API endpoint - List
			public function api_get_list($parameters) {

				// Get lists
				$this->list_id = WS_Form_Common::get_query_var('list_id', false, $parameters);
				$list = self::get_list();

				// Process response
				self::api_response($list);
			}

			// API endpoint - List Subs
			public function api_get_list_subs($parameters) {

				// Get list subs
				$this->list_id = WS_Form_Common::get_query_var('list_id', false, $parameters);
				$list_subs = self::get_list_subs();

				// Process response
				self::api_response($list_subs);
			}

			// API endpoint - List fields
			public function api_get_list_fields($parameters) {

				// Get list fields
				$this->list_id = WS_Form_Common::get_query_var('list_id', false, $parameters);
				$this->list_sub_id = WS_Form_Common::get_query_var('list_sub_id', false, $parameters);
				$list_fields = self::get_list_fields();

				// Process response
				self::api_response($list_fields);
			}

			// API endpoint - Lists with fetch
			public function api_fetch_lists() {

				// Get lists
				$lists = self::get_lists(true);

				// Process response
				self::api_response($lists);
			}

			// API endpoint - List with fetch
			public function api_fetch_list($parameters) {

				// Get lists
				$this->list_id = WS_Form_Common::get_query_var('list_id', false, $parameters);
				$list = self::get_list(true);

				// Process response
				self::api_response($list);
			}

			// API endpoint - List subs with fetch
			public function api_fetch_list_subs($parameters) {

				// Get list subs
				$this->list_id = WS_Form_Common::get_query_var('list_id', false, $parameters);
				$list_subs = self::get_list_subs(true);

				// Process response
				self::api_response($list_subs);
			}

			// API endpoint - List fields with fetch
			public function api_fetch_list_fields($parameters) {

				// Get list fields
				$this->list_id = WS_Form_Common::get_query_var('list_id', false, $parameters);
				$this->list_sub_id = WS_Form_Common::get_query_var('list_sub_id', false, $parameters);
				$list_fields = self::get_list_fields(true);

				// Process response
				self::api_response($list_fields);
			}

			// Convert email to action record ID
			public function ws_form_email_to_action_record_id($email_address) {

				return md5($email_address);
			}
		
			// SVG Logo - Color (Used for the 'Add Form' page)
			public function get_svg_logo_color($list_id = false) {

				$svg_logo = '<g transform="translate(48.000000, 62.000000)"><path d="M43.11108,56.53254 C43.11108,58.4472 41.55828,60 39.64362,60 L3.46734,60 C1.55268,60 0,58.4472 0,56.53254 L0,3.48198 C0,1.56732 1.55268,0.01464 3.46734,0.01464 L26.72784,0.01464 L43.11108,16.79526 L43.11108,56.53254 L43.11108,56.53254 Z" fill="#23A566" fill-rule="nonzero"></path><path d="M28.53348,16.36944 L43.11108,30.29634 L43.06806,16.77372 L43.04376,16.773 L30.16608,16.773 C29.57928,16.773 29.02656,16.62708 28.54218,16.36968 L28.53348,16.36944 L28.53348,16.36944 Z" fill="#1C8F5A" fill-rule="nonzero"></path><path d="M43.11108,16.773 L30.16608,16.773 C28.25142,16.773 26.69862,15.22032 26.69862,13.30566 L26.69862,0 L43.11108,16.773 L43.11108,16.773 Z" fill="#8ED1B1" fill-rule="nonzero"></path><path d="M32.76642,48.90438 L10.34442,48.90438 L10.34442,29.48718 L32.76642,29.48718 L32.76642,48.90438 L32.76642,48.90438 Z M22.94202,32.26104 L22.94202,35.7285 L29.99274,35.7285 L29.99274,32.26104 L22.94202,32.26104 L22.94202,32.26104 Z M22.94202,37.80876 L22.94202,41.04534 L29.99274,41.04534 L29.99274,37.80876 L22.94202,37.80876 L22.94202,37.80876 Z M22.94202,43.1256 L22.94202,46.1304 L29.99274,46.1304 L29.99274,43.1256 L22.94202,43.1256 L22.94202,43.1256 Z M20.16822,46.1304 L20.16822,43.1256 L13.11834,43.1256 L13.11834,46.1304 L20.16822,46.1304 L20.16822,46.1304 Z M20.16822,41.04534 L20.16822,37.80876 L13.11834,37.80876 L13.11834,41.04534 L20.16822,41.04534 L20.16822,41.04534 Z M20.16822,35.7285 L20.16822,32.26104 L13.11834,32.26104 L13.11834,35.7285 L20.16822,35.7285 L20.16822,35.7285 Z" fill="#FFFFFF"></path></g>';

				return $svg_logo;
			}

			// Hex to RGB
			public function hex_to_rgb($color) {

				$default = false;

				// Return default if no color provided
				if(empty($color))  { return $default; }

				// Sanitize $color if "#" is provided 
				if ($color[0] == '#' ) {
					$color = substr( $color, 1 );
				}

				// Check if color has 6 or 3 characters and get values
				if (strlen($color) == 6) {
					$hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
				} elseif ( strlen( $color ) == 3 ) {
					$hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
				} else {
					return $default;
				}

				// Convert hexadec to rgb
				$rgb =  array_map('hexdec', $hex);

				//Return rgb(a) color string
				return array('red' => $rgb[0] / 255, 'green' => $rgb[1] / 255, 'blue' => $rgb[2] / 255);
			}

			public function hex_to_hsl($color) {

				// Sanitize $color if "#" is provided 
				if ($color[0] == '#' ) {
					$color = substr( $color, 1 );
				}

				$color = array($color[0].$color[1], $color[2].$color[3], $color[4].$color[5]);
				$rgb = array_map(function($part) {

					return hexdec($part) / 255;

				}, $color);

				$max = max($rgb);
				$min = min($rgb);

				$l = ($max + $min) / 2;

				if ($max == $min) {

					$h = $s = 0;

				} else {

					$diff = $max - $min;
					$s = $l > 0.5 ? $diff / (2 - $max - $min) : $diff / ($max + $min);

					switch($max) {

						case $rgb[0]:
							$h = ($rgb[1] - $rgb[2]) / $diff + ($rgb[1] < $rgb[2] ? 6 : 0);
							break;

						case $rgb[1]:
							$h = ($rgb[2] - $rgb[0]) / $diff + 2;
							break;

						case $rgb[2]:
							$h = ($rgb[0] - $rgb[1]) / $diff + 4;
							break;
					}

					$h /= 6;
				}

				return array($h, $s, $l);
			}
		}
	});