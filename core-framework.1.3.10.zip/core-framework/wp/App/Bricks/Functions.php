<?php

/**
 * CoreFramework
 *
 * @package   CoreFramework
 * @author    Core Framework <hello@coreframework.com>
 * @copyright 2023 Core Framework
 * @license   EULA + GPLv2
 * @link      https://coreframework.com
 */

declare(strict_types=1);

namespace CoreFramework\App\Bricks;

use CoreFramework\Common\Abstracts\Base;

/**
 * Class Bricks
 *
 * @package CoreFramework\App\Bricks
 * @since 0.0.1
 */
class Functions extends Base {

	/**
	 * Core framework prefix
	 *
	 * @since 0.0.1
	 * @var string
	 */
	public const CORE_SUFFIX = '_c';

	/**
	 * Bricks classes option
	 *
	 * @since 0.0.1
	 * @var string
	 */
	public const BRICKS_CLASSES_OPTION = 'bricks_global_classes';

	/**
	 * Bricks locked classes option
	 *
	 * @since 0.0.1
	 * @var string
	 */
	public const BRICKS_LOCKED_CLASSES_OPTION = 'bricks_global_classes_locked';

	/**
	 * Bricks color palettes option
	 *
	 * @since 0.0.1
	 * @var string
	 */
	public const BRICKS_COLOR_PALETTES_OPTION = 'bricks_color_palette';

	/**
	 * Core Framework color palette name
	 *
	 * @since 0.0.1
	 * @var string
	 */
	public const CORE_COLOR_PALETTE_NAME = 'Core Framework';

	/**
	 * Initialize the class.
	 *
	 * @since 0.0.1
	 */
	public function init(): void {
		/**
		 * @see Requester::is_bricks()
		 * @see Scaffold::__construct
		 *
		 * Add plugin code here
		 */
	}

	/**
	 * Refresh Bricks classes
	 *
	 * @since 0.0.1
	 * @param array $new_core_selectors_array string[]
	 * @return array{status: string}
	 */
	public function refresh_selectors( $new_core_selectors_array ): array {
		$bricks_classes        = get_option( self::BRICKS_CLASSES_OPTION, array() );
		$bricks_locked_classes = get_option( self::BRICKS_LOCKED_CLASSES_OPTION, array() );

		$splitted_array = array(
			'core'   => array(),
			'others' => array(),
		);

		foreach ( $bricks_classes as $class ) {
			if ( str_ends_with( $class['id'], self::CORE_SUFFIX ) ) {
				$splitted_array['core'][] = $class;
				continue;
			}

			$splitted_array['others'][] = $class;
		}

		$core_prev_classes   = $splitted_array['core'];
		$others_prev_classes = $splitted_array['others'];

		$core_prev_classes = array_filter( $core_prev_classes, fn ( $class ): bool => in_array( $class['name'], $new_core_selectors_array ) );

		$locked_classes_to_remove = array_column( array_filter( $core_prev_classes, fn ( $class ): bool => ! in_array( $class['name'], $new_core_selectors_array ) ), 'id' );
		$bricks_locked_classes    = array_filter( $bricks_locked_classes, fn ( $class ): bool => ! in_array( $class, $locked_classes_to_remove ) );

		foreach ( $new_core_selectors_array as $new_core_selector_array ) {
			if ( in_array( $new_core_selector_array, array_column( $core_prev_classes, 'name' ) ) ) {
				continue;
			}

			$id                      = sanitize_title( $new_core_selector_array ) . self::CORE_SUFFIX;
			$core_prev_classes[]     = array(
				'name'     => $new_core_selector_array,
				'id'       => $id,
				'settings' => array(),
			);
			$bricks_locked_classes[] = $id;
		}

		$all = array( ...$others_prev_classes, ...$core_prev_classes );

		update_option( self::BRICKS_CLASSES_OPTION, array_values( $all ), false );
		update_option( self::BRICKS_LOCKED_CLASSES_OPTION, array_values( $bricks_locked_classes ), false );

		return array( 'status' => 'success' );
	}

	/**
	 * Remove Core Framework classes from Bricks
	 * Used when uninstalling/deactivating the plugin
	 *
	 * @since 0.0.1
	 * @return array{status: string}
	 */
	public function remove_selectors(): array {
		$bricks_classes        = get_option( self::BRICKS_CLASSES_OPTION, array() );
		$bricks_locked_classes = get_option( self::BRICKS_LOCKED_CLASSES_OPTION, array() );

		$core_framework_ids = array();

		foreach ( $bricks_classes as $class ) {
			if ( ! str_ends_with( $class['id'], self::CORE_SUFFIX ) ) {
				$core_framework_ids[] = $class['id'];
			}
		}

		if ( is_array( $bricks_classes ) && ! empty( $bricks_classes ) ) {
			$bricks_classes = array_filter( $bricks_classes, fn ( $class ): bool => strpos( $class['id'], self::CORE_SUFFIX ) === false );
		}

		if ( is_array( $bricks_locked_classes ) && ! empty( $bricks_locked_classes ) ) {
			$bricks_locked_classes = array_filter( $bricks_locked_classes, fn ( $class ): bool => in_array( $class, $core_framework_ids ) );
		}

		update_option( self::BRICKS_CLASSES_OPTION, array_values( $bricks_classes ), false );
		update_option( self::BRICKS_LOCKED_CLASSES_OPTION, array_values( $bricks_locked_classes ), false );

		return array( 'status' => 'success' );
	}

	/**
	 * Check if bricks is activated
	 *
	 * @since 0.0.1
	 */
	public function is_bricks(): bool {
		$current_theme = wp_get_theme();
		return 'Bricks' === $current_theme->name || 'Bricks' === $current_theme->parent_theme;
	}

	/**
	 * handle bricks builder deactivation
	 * Remove classes and folder on deactivation
	 *
	 * @since 0.0.1
	 */
	public function handle_uninstall(): void {
		if ( ! $this->is_bricks() ) {
			return;
		}

		$this->remove_selectors();
		$this->remove_colors();
	}

	/**
	 * Add colors to Bricks color system
	 * Color palette structure:
	 *     Array(
	 *         [0] => Array(
	 *             [id] => 66a6c2
	 *             [name] => Default
	 *             [colors] => Array(
	 *            [0] => Array(
	 *                [hex] => #f5f5f5 // One of type : "HEX", "RGB", "HSL", "RAW"
	 *                [id] => 47f036
	 *                [name] => Color #1
	 *
	 * @since 0.0.1
	 * @param array $new_colors { id: string, raw: string, value: string, name: string }
	 * @return array{status: string}
	 */
	public function update_colors( $new_colors ): array {
		$bricks_colors = get_option( self::BRICKS_COLOR_PALETTES_OPTION, array() );

		if ( empty( $bricks_colors ) ) {
			$bricks_colors = array();
		}

		$core_palette   = array();
		$others_palette = array();

		for ( $i = 0; $i < ( is_countable( $bricks_colors ) ? count( $bricks_colors ) : 0 ); $i++ ) {
			if ( str_ends_with( $bricks_colors[ $i ]['id'], self::CORE_SUFFIX ) ) {
				continue;
			}

			$others_palette[] = $bricks_colors[ $i ];
		}

		$core_id        = 'core_framework' . self::CORE_SUFFIX;
		$core_palette[] = array(
			'id'     => $core_id,
			'name'   => self::CORE_COLOR_PALETTE_NAME,
			'colors' => array(),
		);

		foreach ( $new_colors as $new_color ) {
			if ( isset( $new_color['dark'] ) && $new_color['dark'] ) {
				continue;
			}

			$core_palette[0]['colors'][] = array(
				'raw'  => $new_color['raw'],
				'id'   => $new_color['id'],
				'name' => $new_color['name'],
			);
		}

		$all = array( ...$others_palette, ...$core_palette );

		update_option( self::BRICKS_COLOR_PALETTES_OPTION, array_values( $all ), false );

		return array( 'status' => 'success' );
	}

	/**
	 * Remove colors and color set from Bricks color system
	 *
	 * @since 0.0.1
	 */
	public function remove_colors(): void {
		$bricks_colors  = get_option( self::BRICKS_COLOR_PALETTES_OPTION, array() );
		$others_palette = array_filter( $bricks_colors, fn ( $palette ): bool => ! str_ends_with( $palette['id'], self::CORE_SUFFIX ) );

		update_option( self::BRICKS_COLOR_PALETTES_OPTION, array_values( $others_palette ), false );
	}

	/**
	 * Determine loading of integration
	 *
	 * @since 1.1.2
	 */
	public function determine_load(): bool {
		$option  = get_option( 'core_framework_main', array() );
		$license = get_option( 'core_framework_bricks_license_key', false );
		return isset( $option['bricks'] ) && $option['bricks'] && $license;
	}
}
