<?php

	class WS_Form_Data_Source_Google_Sheets_V4 extends WS_Form_Data_Source {

		public $id = 'googlesheetsv4';
		public $pro_required = true;
		public $label;
		public $label_retrieving;
		public $records_per_page = 1000;

		public function __construct() {

			// Set label
			$this->label = __('Google Sheets', 'ws-form-google-sheets-v4');

			// Set label retrieving
			$this->label_retrieving = __('Retrieving Sheet...', 'ws-form-google-sheets-v4');

			// Register action
			parent::register($this);

			// Register config filters
			add_filter('wsf_config_meta_keys', array($this, 'config_meta_keys'), 10, 2);

			// Register API endpoint
			add_action('rest_api_init', array($this, 'rest_api_init'), 10, 0);

			// Records per page
			$this->records_per_page = apply_filters('wsf_data_source_' . $this->id . '_records_per_age', $this->records_per_page);
		}

		// Get
		public function get($form_object, $field_id, $page, $meta_key, $meta_value, $no_paging = false, $api_request = false) {

			// Check meta key
			if(empty($meta_key)) { return self::error(__('No meta key specified', 'ws-form-google-sheets-v4'), $field_id, $this, $api_request); }

			// Get meta key config
			$meta_keys = WS_Form_Config::get_meta_keys();
			if(!isset($meta_keys[$meta_key])) { return self::error(__('Unknown meta key', 'ws-form-google-sheets-v4'), $field_id, $this, $api_request); }
			$meta_key_config = $meta_keys[$meta_key];

			// Check meta value
			if(
				!is_object($meta_value) ||
				!isset($meta_value->columns) ||
				!isset($meta_value->groups) ||
				!isset($meta_value->groups[0])
			) {

				if(!isset($meta_key_config['default'])) { return self::error(__('No default value', 'ws-form-google-sheets-v4'), $field_id, $this, $api_request); }

				// If meta_value is invalid, create one from default
				$meta_value = json_decode(json_encode($meta_key_config['default']));
			}

			// Get file ID
			$list_id = $this->data_source_googlesheetsv4_list_id;
			if($list_id === '') {

				// Return data
				return self::error(__('Invalid file', 'ws-form-google-sheets-v4'), $field_id, $this, $api_request);
			}

			// Get sheet ID
			$list_sub_id = $this->data_source_googlesheetsv4_list_sub_id;
			if($list_sub_id === '') {

				// Return data
				return self::error(__('Invalid sheet', 'ws-form-google-sheets-v4'), $field_id, $this, $api_request);
			}

			$googlesheetsv4_obj = new WS_Form_Action_Google_Sheets_V4(false);
			$googlesheetsv4_obj->list_id = $list_id;
			$googlesheetsv4_obj->list_sub_id = $list_sub_id;

			$values = $googlesheetsv4_obj->get_sheet();

			if($values === false) {

				// Return data
				return self::error(__('No sheet data found', 'ws-form-google-sheets-v4'), $field_id, $this, $api_request);
			}

			$column_count = 0;
			$rows = array();

		    foreach($values as $row_index => $row) {

		    	if($row_index === 0) {

					$meta_value->columns = array();

					foreach($row as $column_index => $label) {

						$meta_value->columns[] = (object) array('id' => $column_index, 'label' => $label);

						$column_count++;
					}

		    	} else {

		    		// Build row data
		    		$row_data = array_fill(0, $column_count, '');

		    		foreach($row as $column_index => $value) {

		    			$row_data[$column_index] = $value;
		    		}

					$row = (object) array(

						'id'		=> $row_index - 1,
						'default'	=> '',
						'required'	=> '',
						'disabled'	=> '',
						'hidden'	=> '',
						'data'		=> $row_data
					);

					$rows[] = $row;
		    	}
		    }

			$meta_value->groups[0]->rows = $rows;

			// Return data
			return array('error' => false, 'error_message' => '', 'meta_value' => $meta_value, 'max_num_pages' => 0, 'meta_keys' => array());
		}

		// Get meta keys
		public function get_data_source_meta_keys() {

			return array(

				'data_source_' . $this->id . '_list_id',
				'data_source_' . $this->id . '_list_sub_id',
				'data_source_recurrence'
			);
		}

		// Get settings
		public function get_data_source_settings() {

			// Build settings
			$settings = array(

				'meta_keys' => self::get_data_source_meta_keys()
			);

 			// Add retrieve button
			$settings['meta_keys'][] = 'data_source_' . $this->id . '_get';

			// Wrap settings so they will work with sidebar_html function in admin.js
			$settings = parent::get_settings_wrapper($settings);

			// Add label
			$settings->label = $this->label;

			// Add label retrieving
			$settings->label_retrieving = $this->label_retrieving;

			// Add API GET endpoint
			$settings->endpoint_get = 'data-source/' . $this->id . '/';

			// Apply filter
			$settings = apply_filters('wsf_data_source_' . $this->id . '_settings', $settings);

			return $settings;
		}

		// Meta keys for this action
		public function config_meta_keys($meta_keys = array(), $form_id = 0) {

			// Build config_meta_keys
			$config_meta_keys = array(

				// File
				'data_source_' . $this->id . '_list_id' => array(

					'label'						=>	__('File', 'ws-form-google-sheets-v4'),
					'type'						=>	'select',
					'help'						=>	__('Select which file to use.', 'ws-form-google-sheets-v4'),
					'options'					=>	'action_api_populate',
					'options_blank'				=>	__('Select...', 'ws-form-google-sheets-v4'),
					'options_action_id'			=>	$this->id,
					'options_action_api_populate'	=>	'lists',
					'reload'					=>	array(

						'action_id'			=>	$this->id,
						'method'			=>	'lists_fetch'
					)
				),

				// Sheet
				'data_source_' . $this->id . '_list_sub_id' => array(

					'label'						=>	__('Sheet', 'ws-form-google-sheets-v4'),
					'type'						=>	'select',
					'help'						=>	__('Select which sheet to use.', 'ws-form-google-sheets-v4'),
					'options'					=>	'action_api_populate',
					'options_blank'				=>	__('Select...', 'ws-form-google-sheets-v4'),
					'options_action_id'			=>	$this->id,
					'options_list_id_meta_key'	=>	'data_source_' . $this->id . '_list_id',
					'options_action_api_populate'	=>	'list_subs',
					'reload'					=>	array(

						'action_id'			=>	$this->id,
						'method'			=>	'list_subs_fetch',
						'list_id_meta_key'	=>	'data_source_' . $this->id . '_list_id'
					),
					'condition'						=>	array(

						array(

							'logic'			=>	'!=',
							'meta_key'		=>	'data_source_' . $this->id . '_list_id',
							'meta_value'	=>	''
						)
					)
				),

				// Get Data
				'data_source_' . $this->id . '_get' => array(

					'label'						=>	__('Get Data', 'ws-form-google-sheets-v4'),
					'type'						=>	'button',
					'condition'					=>	array(

						array(

							'logic'				=>	'!=',
							'meta_key'			=>	'data_source_' . $this->id . '_list_id',
							'meta_value'		=>	''
						),

						array(

							'logic'				=>	'!=',
							'meta_key'			=>	'data_source_' . $this->id . '_list_sub_id',
							'meta_value'		=>	''
						)
					),
					'key'						=>	'data_source_get'
				)
			);

			// Merge
			$meta_keys = array_merge($meta_keys, $config_meta_keys);

			return $meta_keys;
		}

		// Build REST API endpoints
		public function rest_api_init() {

			// Get data source
			register_rest_route(WS_FORM_RESTFUL_NAMESPACE, '/data-source/' . $this->id . '/', array('methods' => 'POST', 'callback' => array($this, 'api_post'), 'permission_callback' => function () { return WS_Form_Common::can_user('edit_form'); }));
		}

		// api_post
		public function api_post() {

			// Get meta keys
			$meta_keys = self::get_data_source_meta_keys();

			// Read settings
			foreach($meta_keys as $meta_key) {

				$this->{$meta_key} = WS_Form_Common::get_query_var($meta_key, false);
				if(
					is_object($this->{$meta_key}) ||
					is_array($this->{$meta_key})
				) {

					$this->{$meta_key} = json_decode(json_encode($this->{$meta_key}));
				}
			}

			// Get field ID
			$field_id = WS_Form_Common::get_query_var('field_id', 0);

			// Get page
			$page = intval(WS_Form_Common::get_query_var('page', 1));

			// Get meta key
			$meta_key = WS_Form_Common::get_query_var('meta_key', 0);

			// Get meta value
			$meta_value = WS_Form_Common::get_query_var('meta_value', 0);

			// Get return data
			$get_return = self::get(false, $field_id, $page, $meta_key, $meta_value, false, true);

			// Error checking
			if($get_return['error']) {

				// Error
				return self::api_error($get_return);

			} else {

				// Success
				return $get_return;
			}
		}
	}

	new WS_Form_Data_Source_Google_Sheets_V4();
