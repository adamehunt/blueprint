<?php

namespace Wpcb2\Service\Minify;


class MinifyNull {


    public function minify($code)
    {
        return $code;
    }

}
