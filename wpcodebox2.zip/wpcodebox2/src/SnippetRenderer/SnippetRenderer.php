<?php

namespace Wpcb2\SnippetRenderer;


class SnippetRenderer
{

    public function __construct()
    {
    }
}
