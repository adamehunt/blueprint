# Important Note

### These files are purely dumps from my code manager "WPCodeBox" 
You will need to import the partials into the Framework SASS file for this to work.