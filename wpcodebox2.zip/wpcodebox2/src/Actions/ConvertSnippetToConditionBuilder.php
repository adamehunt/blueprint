<?php


namespace Wpcb2\Actions;


class ConvertSnippetToConditionBuilder
{
    public function execute($snippet_id)
    {


    }
}
